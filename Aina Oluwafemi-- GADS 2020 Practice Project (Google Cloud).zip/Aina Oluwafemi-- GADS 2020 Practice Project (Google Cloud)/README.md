# GADS2020-Phase-2-Projects
This repository contains 15 labs and 3 Lab Translations for GADS2020 Phase 2 projects in the Google Cloud Platform Track<br/>
Done by Tichaona Ngatiane.<br/>
Email: ngattich@gmail.com

# LIST OF CONTENTS
## Translations
AK8S-03 Creating a GKE Cluster via GCP Console.md<br/>
Implement Private Google Access and Cloud NAT.md<br/>
VPC networking.md

## Labs
1. 
AK8S-03 Creating a GKE Cluster via GCP Console.png<br/>
AK8S-14 Securing Kubernetes Engine with Cloud IAM and Pod Security Policies.png<br/>
AK8S-18 Using Cloud SQL with Kubernetes Engine.png<br/>
Automating the Deployment of Infrastructure Using Deployment Manager.png<br/>
Automating the Deployment of Infrastructure Using Terraform.png<br/>
Cloud Storage.png<br/>
Creating Virtual Machines.png<br/>
Error reporting and debugging.png<br/>
Examining billing data with BQ.png<br/>
Implement private google access and NAT.png<br/>
implementing cloud sql.png<br/>
resource monitoring.png<br/>
Virtual Private Networks.png<br/>
vpc networking.png<br/>
Working with Virtual Machines.png<br/>

Course: Google Cloud Platform Fundamentals - Core Infrastructure
Module: Getting Started with Google Cloud Platform
GCP Fundamentals: Getting Started with Cloud Marketplace
